#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

union temp {

     int    a;
     char   c;
     float  b;
     double d;


};

/*
struct temp2 {

     int    a;
     char   c;
     float  b;
     double d;


}stuct_obj;*/


int main()
{

  union temp local_obj;
   
   local_obj.c = 'a';
      
  // printf("%c \n" , local_obj.c);
   local_obj.a = 10 ;
   printf("%c %d \n",local_obj.c,local_obj.a);
   
  exit(EXIT_SUCCESS);
}
